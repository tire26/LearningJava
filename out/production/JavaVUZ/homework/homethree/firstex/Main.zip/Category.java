package homework.homethree.firstex;

import java.util.Scanner;

public class Category {
    String name;
    Product[] products;

    public  Category(String name, Product[] products) {
        this.name = name;
        this.products = products;
    }
}
