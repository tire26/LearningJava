package homework.homethree.secondex;

public class Student {
    private String surname;
    private String numberOfGroup;
    private int[] marks;

    public Student(String surname, String numberOfGroup, int[] marks) {
        this.surname = surname;
        this.numberOfGroup = numberOfGroup;
        this.marks = marks;
    }
}
